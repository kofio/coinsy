//
//  GRProBox.h
//  GRProKit
//
//  Created by Guilherme Rambo on 02/11/13.
//  Copyright (c) 2013 Guilherme Rambo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface GRProBox : NSView

@property (nonatomic, copy) NSString *title;

@end
