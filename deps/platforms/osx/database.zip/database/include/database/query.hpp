
#ifndef DATABASE_QUERY_HPP
#define DATABASE_QUERY_HPP

#include <map>
#include <string>

namespace database {

    class query
    {
        public:
        
            /**
             * Constructor
             * @param val The value.
             */
            explicit query(const std::string & val);
        
            /**
             * The query string.
             */
            const std::string & str() const;

            /**
             * The kay/value pairs.
             */
            std::map<std::string, std::string> & pairs();
        
            /**
             * The public pairs.
             */
            std::map<std::string, std::string> & pairs_public();
        
        private:
        
            /**
             * URI decodes.
             * @param val The value.
             */
            static std::string uri_decode(const std::string &);
        
            /**
             * URI encodes.
             * @param val The value.
             */
            static std::string uri_encode(const std::string &);
        
            /**
             * The query string.
             */
            std::string m_str;
        
            /**
             * The key/value pairs.
             */
            std::map<std::string, std::string> m_pairs;
        
            /**
             * The public key/value pairs.
             */
            std::map<std::string, std::string> m_pairs_public;
        
        protected:
        
            // ...
    };
    
} // namespace database

#endif // DATABASE_QUERY_HPP
