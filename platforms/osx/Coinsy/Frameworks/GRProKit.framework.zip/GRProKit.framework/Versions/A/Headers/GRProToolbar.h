//
//  GRProToolbar.h
//  GRProKit
//
//  Created by Guilherme Rambo on 03/11/13.
//  Copyright (c) 2013 Guilherme Rambo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// currently this class doesn't override anything
@interface GRProToolbar : NSToolbar

@end