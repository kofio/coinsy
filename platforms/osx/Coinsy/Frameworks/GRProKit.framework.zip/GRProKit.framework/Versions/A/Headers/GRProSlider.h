//
//  GRProSlider.h
//  GRProKit
//
//  Created by Guilherme Rambo on 03/11/13.
//  Copyright (c) 2013 Guilherme Rambo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface GRProSlider : NSSlider

@end

@interface GRProSliderCell : NSSliderCell

@end
