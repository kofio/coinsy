//
//  GRProTableView.h
//  TableViewTest
//
//  Created by Guilherme Rambo on 17/12/13.
//  Copyright (c) 2013 Guilherme Rambo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface GRProTableView : NSTableView

@end
